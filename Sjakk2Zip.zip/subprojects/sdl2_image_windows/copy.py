#!/usr/bin/env python3 

import sys, shutil
shutil.copyfile(sys.argv[1], sys.argv[2])